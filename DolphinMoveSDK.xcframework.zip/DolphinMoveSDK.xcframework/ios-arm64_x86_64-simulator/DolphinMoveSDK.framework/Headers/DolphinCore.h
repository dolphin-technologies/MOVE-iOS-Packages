//
//  MoveSDK
//
//  Copyright © 2024 Dolphin Technologies GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for DolphinCore.
FOUNDATION_EXPORT double DolphinCoreVersionNumber;

//! Project version string for DolphinCore.
FOUNDATION_EXPORT const unsigned char DolphinCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DolphinCore/PublicHeader.h>


