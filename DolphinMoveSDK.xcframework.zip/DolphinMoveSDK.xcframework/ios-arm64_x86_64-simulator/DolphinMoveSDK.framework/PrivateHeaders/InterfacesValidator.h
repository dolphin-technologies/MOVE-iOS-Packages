//
//  Copyright © 2024 Dolphin Technologies GmbH. All rights reserved.
//

/// Check WiFi C function.
int CheckWiFi(void);

/// Check WWAN C function.
int CheckWWAN(void);
